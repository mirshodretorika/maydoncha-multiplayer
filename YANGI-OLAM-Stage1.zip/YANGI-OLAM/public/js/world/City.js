import * as THREE from 'three';

const GRID = 70;
const ROAD_WIDTH = 15;
const WORLD_SIZE = 560;

function seededRandom(seed) {
  let state = seed >>> 0;
  return () => {
    state = (state * 1664525 + 1013904223) >>> 0;
    return state / 4294967296;
  };
}

function makeFacadeTexture(baseColor, seed) {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');
  const random = seededRandom(seed);
  ctx.fillStyle = baseColor;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  for (let y = 12; y < 250; y += 25) {
    for (let x = 8; x < 124; x += 22) {
      const lit = random() > 0.62;
      ctx.fillStyle = lit ? '#f2c879' : '#182536';
      ctx.fillRect(x, y, 12, 15);
      ctx.fillStyle = lit ? 'rgba(255,238,190,.22)' : 'rgba(160,190,220,.17)';
      ctx.fillRect(x + 1, y + 1, 10, 2);
      ctx.fillStyle = 'rgba(8,12,18,.35)';
      ctx.fillRect(x + 5, y, 1, 15);
    }
  }
  ctx.fillStyle = 'rgba(0,0,0,.14)';
  ctx.fillRect(0, 0, 5, canvas.height);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.anisotropy = 2;
  return texture;
}

export class City {
  constructor(scene) {
    this.scene = scene;
    this.colliders = [];
    this.worldLimit = 274;
    this.clock = 0;
    this.random = seededRandom(2036);
    this.facadeMaterials = [
      '#66717f', '#777b80', '#6d7773', '#8a8175', '#536578', '#777087'
    ].map((color, index) => new THREE.MeshStandardMaterial({
      map: makeFacadeTexture(color, 100 + index),
      roughness: 0.84,
      metalness: 0.08
    }));

    this._buildGround();
    this._buildRoadNetwork();
    this._buildBuildings();
    this._buildParks();
    this._buildStreetFurniture();
  }

  _buildGround() {
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(660, 660),
      new THREE.MeshStandardMaterial({ color: 0x4b594b, roughness: 1 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.12;
    ground.receiveShadow = true;
    this.scene.add(ground);

    const horizon = new THREE.Mesh(
      new THREE.PlaneGeometry(2000, 2000),
      new THREE.MeshBasicMaterial({ color: 0x778a99 })
    );
    horizon.rotation.x = -Math.PI / 2;
    horizon.position.y = -0.16;
    this.scene.add(horizon);
  }

  _buildRoadNetwork() {
    const asphalt = new THREE.MeshStandardMaterial({ color: 0x292f36, roughness: 0.92, metalness: 0.02 });
    const sidewalk = new THREE.MeshStandardMaterial({ color: 0x777a7b, roughness: 1 });
    const roadGeometryX = new THREE.PlaneGeometry(WORLD_SIZE, ROAD_WIDTH);
    const roadGeometryZ = new THREE.PlaneGeometry(ROAD_WIDTH, WORLD_SIZE);
    const sidewalkGeometryX = new THREE.PlaneGeometry(WORLD_SIZE, 2.2);
    const sidewalkGeometryZ = new THREE.PlaneGeometry(2.2, WORLD_SIZE);

    for (let index = -4; index <= 4; index += 1) {
      const coordinate = index * GRID;
      const horizontal = new THREE.Mesh(roadGeometryX, asphalt);
      horizontal.rotation.x = -Math.PI / 2;
      horizontal.position.set(0, 0.005, coordinate);
      horizontal.receiveShadow = true;
      this.scene.add(horizontal);

      const vertical = new THREE.Mesh(roadGeometryZ, asphalt);
      vertical.rotation.x = -Math.PI / 2;
      vertical.position.set(coordinate, 0.006, 0);
      vertical.receiveShadow = true;
      this.scene.add(vertical);

      for (const side of [-1, 1]) {
        const sideX = new THREE.Mesh(sidewalkGeometryX, sidewalk);
        sideX.rotation.x = -Math.PI / 2;
        sideX.position.set(0, 0.025, coordinate + side * (ROAD_WIDTH / 2 + 1.1));
        this.scene.add(sideX);

        const sideZ = new THREE.Mesh(sidewalkGeometryZ, sidewalk);
        sideZ.rotation.x = -Math.PI / 2;
        sideZ.position.set(coordinate + side * (ROAD_WIDTH / 2 + 1.1), 0.026, 0);
        this.scene.add(sideZ);
      }
    }

    // A single InstancedMesh draws all broken yellow road-centre markings.
    const dashGeometry = new THREE.BoxGeometry(3.2, 0.035, 0.13);
    const dashMaterial = new THREE.MeshBasicMaterial({ color: 0xd4b967 });
    const dashCount = 9 * 31 * 2;
    const dashes = new THREE.InstancedMesh(dashGeometry, dashMaterial, dashCount);
    const dummy = new THREE.Object3D();
    let cursor = 0;
    for (let road = -4; road <= 4; road += 1) {
      for (let segment = -15; segment <= 15; segment += 1) {
        const offset = segment * 17.5;
        dummy.position.set(offset, 0.045, road * GRID);
        dummy.rotation.set(0, 0, 0);
        dummy.updateMatrix();
        dashes.setMatrixAt(cursor++, dummy.matrix);
        dummy.position.set(road * GRID, 0.045, offset);
        dummy.rotation.y = Math.PI / 2;
        dummy.updateMatrix();
        dashes.setMatrixAt(cursor++, dummy.matrix);
      }
    }
    dashes.instanceMatrix.needsUpdate = true;
    this.scene.add(dashes);
  }

  _buildBuildings() {
    const geometryCache = new Map();
    for (let ix = -4; ix <= 3; ix += 1) {
      for (let iz = -4; iz <= 3; iz += 1) {
        const centerX = ix * GRID + GRID / 2;
        const centerZ = iz * GRID + GRID / 2;
        if ((ix === -2 && iz === 1) || (ix === 2 && iz === -2) || (ix === 0 && iz === 3)) continue;

        for (let slot = 0; slot < 4; slot += 1) {
          const column = slot % 2;
          const row = Math.floor(slot / 2);
          const width = 12 + this.random() * 8;
          const depth = 12 + this.random() * 8;
          const height = 12 + Math.pow(this.random(), 0.72) * (slot === 0 ? 48 : 34);
          const x = centerX + (column === 0 ? -15 : 15) + (this.random() - 0.5) * 2;
          const z = centerZ + (row === 0 ? -15 : 15) + (this.random() - 0.5) * 2;
          const colorIndex = Math.floor(this.random() * this.facadeMaterials.length);
          const key = `${width.toFixed(2)}_${height.toFixed(2)}_${depth.toFixed(2)}`;
          let geometry = geometryCache.get(key);
          if (!geometry) {
            geometry = new THREE.BoxGeometry(width, height, depth);
            geometryCache.set(key, geometry);
          }
          const building = new THREE.Mesh(geometry, this.facadeMaterials[colorIndex]);
          building.position.set(x, height / 2, z);
          building.castShadow = true;
          building.receiveShadow = true;
          this.scene.add(building);
          this.colliders.push({
            minX: x - width / 2 - 0.35,
            maxX: x + width / 2 + 0.35,
            minZ: z - depth / 2 - 0.35,
            maxZ: z + depth / 2 + 0.35
          });

          // Rooftop equipment gives the skyline a little more depth.
          if (height > 27 && this.random() > 0.42) {
            const unit = new THREE.Mesh(
              new THREE.BoxGeometry(2.1, 1.1, 2.1),
              new THREE.MeshStandardMaterial({ color: 0x424a51, roughness: 0.9 })
            );
            unit.position.set(x + width * 0.18, height + 0.55, z - depth * 0.12);
            unit.castShadow = true;
            this.scene.add(unit);
          }
        }
      }
    }
  }

  _buildParks() {
    const parkMaterial = new THREE.MeshStandardMaterial({ color: 0x597d58, roughness: 1 });
    const trunkMaterial = new THREE.MeshStandardMaterial({ color: 0x5c4432, roughness: 1 });
    const leafMaterial = new THREE.MeshStandardMaterial({ color: 0x477d51, roughness: 1 });
    const trunkGeometry = new THREE.CylinderGeometry(0.22, 0.34, 3.2, 6);
    const crownGeometry = new THREE.SphereGeometry(1.55, 7, 6);

    const parks = [
      { x: -105, z: 105 },
      { x: 175, z: -105 },
      { x: 35, z: 245 }
    ];
    const totalTrees = parks.length * 9;
    const trunkInstances = new THREE.InstancedMesh(trunkGeometry, trunkMaterial, totalTrees);
    const crownInstances = new THREE.InstancedMesh(crownGeometry, leafMaterial, totalTrees);
    const dummy = new THREE.Object3D();
    let index = 0;

    for (const park of parks) {
      const lawn = new THREE.Mesh(new THREE.PlaneGeometry(45, 45), parkMaterial);
      lawn.rotation.x = -Math.PI / 2;
      lawn.position.set(park.x, 0.035, park.z);
      lawn.receiveShadow = true;
      this.scene.add(lawn);

      for (let i = 0; i < 9; i += 1) {
        const x = park.x + ((i % 3) - 1) * 13 + (this.random() - 0.5) * 3;
        const z = park.z + (Math.floor(i / 3) - 1) * 13 + (this.random() - 0.5) * 3;
        dummy.position.set(x, 1.65, z);
        dummy.scale.setScalar(0.85 + this.random() * 0.35);
        dummy.updateMatrix();
        trunkInstances.setMatrixAt(index, dummy.matrix);
        dummy.position.y = 3.9;
        dummy.scale.setScalar(0.8 + this.random() * 0.45);
        dummy.updateMatrix();
        crownInstances.setMatrixAt(index, dummy.matrix);
        index += 1;
      }
    }
    trunkInstances.instanceMatrix.needsUpdate = true;
    trunkInstances.castShadow = true;
    crownInstances.instanceMatrix.needsUpdate = true;
    crownInstances.castShadow = true;
    this.scene.add(trunkInstances, crownInstances);
  }

  _buildStreetFurniture() {
    const poleGeometry = new THREE.CylinderGeometry(0.09, 0.13, 6.5, 6);
    const poleMaterial = new THREE.MeshStandardMaterial({ color: 0x343b43, metalness: 0.55, roughness: 0.55 });
    const bulbGeometry = new THREE.SphereGeometry(0.24, 8, 6);
    const bulbMaterial = new THREE.MeshStandardMaterial({
      color: 0xffdca2,
      emissive: 0xffae55,
      emissiveIntensity: 0.65,
      roughness: 0.4
    });
    const positions = [];
    for (let road = -4; road <= 4; road += 1) {
      for (let segment = -3; segment <= 3; segment += 1) {
        const point = segment * 75;
        if (Math.abs(point - road * GRID) < 16) continue;
        positions.push([point, road * GRID + 9.7]);
        positions.push([road * GRID + 9.7, point]);
      }
    }
    const poles = new THREE.InstancedMesh(poleGeometry, poleMaterial, positions.length);
    const bulbs = new THREE.InstancedMesh(bulbGeometry, bulbMaterial, positions.length);
    const dummy = new THREE.Object3D();
    positions.forEach(([x, z], index) => {
      dummy.position.set(x, 3.25, z);
      dummy.rotation.z = 0;
      dummy.updateMatrix();
      poles.setMatrixAt(index, dummy.matrix);
      dummy.position.set(x, 6.45, z);
      dummy.updateMatrix();
      bulbs.setMatrixAt(index, dummy.matrix);
    });
    poles.instanceMatrix.needsUpdate = true;
    bulbs.instanceMatrix.needsUpdate = true;
    poles.castShadow = true;
    this.scene.add(poles, bulbs);
  }

  collides(x, z, radius = 0.55) {
    if (Math.abs(x) > this.worldLimit - radius || Math.abs(z) > this.worldLimit - radius) return true;
    for (const box of this.colliders) {
      if (x + radius > box.minX && x - radius < box.maxX && z + radius > box.minZ && z - radius < box.maxZ) {
        return true;
      }
    }
    return false;
  }

  update(delta) {
    this.clock += delta;
  }
}
