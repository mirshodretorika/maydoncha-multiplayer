import * as THREE from 'three';

export class VehicleController {
  constructor(scene) {
    this.scene = scene;
    this.position = new THREE.Vector3(8, 0, 0);
    this.yaw = 0;
    this.speed = 0;
    this.occupied = false;
    this.keys = new Set();
    this.steering = 0;
    this.model = this._createCar();
    this.model.position.copy(this.position);
    this.scene.add(this.model);
  }

  _createCar() {
    const root = new THREE.Group();
    const bodyMaterial = new THREE.MeshStandardMaterial({ color: 0x9e2432, metalness: 0.48, roughness: 0.36 });
    const trimMaterial = new THREE.MeshStandardMaterial({ color: 0x171d24, metalness: 0.35, roughness: 0.54 });
    const glassMaterial = new THREE.MeshStandardMaterial({ color: 0x243d50, metalness: 0.18, roughness: 0.18, transparent: true, opacity: 0.88 });
    const lightMaterial = new THREE.MeshStandardMaterial({ color: 0xfff1cd, emissive: 0xffd18a, emissiveIntensity: 1.2 });
    const rearLightMaterial = new THREE.MeshStandardMaterial({ color: 0x8d1019, emissive: 0xff142a, emissiveIntensity: 0.7 });
    const tireMaterial = new THREE.MeshStandardMaterial({ color: 0x101317, roughness: 0.94 });
    const rimMaterial = new THREE.MeshStandardMaterial({ color: 0x98a0a6, metalness: 0.8, roughness: 0.34 });

    const chassis = new THREE.Mesh(new THREE.BoxGeometry(2.05, 0.56, 4.15), bodyMaterial);
    chassis.position.y = 0.82;
    chassis.castShadow = true;
    root.add(chassis);

    const hood = new THREE.Mesh(new THREE.BoxGeometry(1.94, 0.18, 1.04), bodyMaterial);
    hood.position.set(0, 1.12, -1.35);
    hood.castShadow = true;
    root.add(hood);

    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.66, 0.78, 1.95), glassMaterial);
    cabin.position.set(0, 1.43, 0.18);
    cabin.castShadow = true;
    root.add(cabin);

    const roof = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.13, 1.78), bodyMaterial);
    roof.position.set(0, 1.87, 0.2);
    roof.castShadow = true;
    root.add(roof);

    const bumperFront = new THREE.Mesh(new THREE.BoxGeometry(2.08, 0.2, 0.18), trimMaterial);
    bumperFront.position.set(0, 0.59, -2.08);
    root.add(bumperFront);
    const bumperBack = bumperFront.clone();
    bumperBack.position.z = 2.08;
    root.add(bumperBack);

    this.wheels = [];
    for (const x of [-1.06, 1.06]) {
      for (const z of [-1.35, 1.35]) {
        const wheelPivot = new THREE.Group();
        wheelPivot.position.set(x, 0.43, z);
        const tire = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 0.27, 16), tireMaterial);
        tire.rotation.z = Math.PI / 2;
        tire.castShadow = true;
        wheelPivot.add(tire);
        const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.285, 12), rimMaterial);
        rim.rotation.z = Math.PI / 2;
        wheelPivot.add(rim);
        root.add(wheelPivot);
        this.wheels.push({ pivot: wheelPivot, tire, front: z < 0 });
      }
    }

    for (const x of [-0.68, 0.68]) {
      const headlight = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.16, 0.06), lightMaterial);
      headlight.position.set(x, 0.98, -2.1);
      root.add(headlight);
      const rear = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.15, 0.06), rearLightMaterial);
      rear.position.set(x, 0.98, 2.1);
      root.add(rear);
    }

    const shadow = new THREE.Mesh(
      new THREE.PlaneGeometry(2.9, 5.1),
      new THREE.MeshBasicMaterial({ color: 0x0b1015, transparent: true, opacity: 0.28, depthWrite: false })
    );
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = 0.018;
    root.add(shadow);
    return root;
  }

  handleKey(code, isDown) {
    if (isDown) this.keys.add(code);
    else this.keys.delete(code);
  }

  get cameraTarget() {
    return new THREE.Vector3(this.position.x, this.position.y + 1.35, this.position.z);
  }

  canEnter(playerPosition, maxDistance = 10) {
    return this.position.distanceTo(new THREE.Vector3(playerPosition.x, 0, playerPosition.z)) <= maxDistance;
  }

  enter() {
    this.occupied = true;
    this.speed = 0;
    this.keys.clear();
  }

  exitPosition(city) {
    const sideX = Math.cos(this.yaw) * 2.2;
    const sideZ = -Math.sin(this.yaw) * 2.2;
    const options = [
      new THREE.Vector3(this.position.x + sideX, 0, this.position.z + sideZ),
      new THREE.Vector3(this.position.x - sideX, 0, this.position.z - sideZ),
      new THREE.Vector3(this.position.x, 0, this.position.z + 3.2)
    ];
    return options.find(point => !city.collides(point.x, point.z, 0.5)) || null;
  }

  leave() {
    this.occupied = false;
    this.keys.clear();
  }

  reset(position = new THREE.Vector3(8, 0, 0), yaw = 0) {
    this.position.copy(position);
    this.yaw = yaw;
    this.speed = 0;
    this.steering = 0;
    this.occupied = false;
    this.keys.clear();
    this.model.position.copy(this.position);
    this.model.rotation.y = this.yaw;
  }

  update(delta, city) {
    const forward = this.keys.has('KeyW') ? 1 : 0;
    const reverse = this.keys.has('KeyS') ? 1 : 0;
    const steerInput = (this.keys.has('KeyD') ? 1 : 0) - (this.keys.has('KeyA') ? 1 : 0);
    const handBrake = this.keys.has('Space');

    if (forward) this.speed += 18 * delta;
    if (reverse) this.speed -= (this.speed > 1 ? 28 : 11) * delta;
    if (!forward && !reverse) this.speed *= Math.exp(-(handBrake ? 5.2 : 1.25) * delta);
    if (handBrake && (forward || reverse)) this.speed *= Math.exp(-2.5 * delta);
    this.speed = THREE.MathUtils.clamp(this.speed, -9, 27);

    this.steering = THREE.MathUtils.lerp(this.steering, steerInput, 1 - Math.exp(-8 * delta));
    const speedFactor = THREE.MathUtils.clamp(Math.abs(this.speed) / 8, 0, 1.25);
    if (Math.abs(this.speed) > 0.15) {
      this.yaw += this.steering * speedFactor * 1.18 * delta * Math.sign(this.speed);
    }

    const directionX = -Math.sin(this.yaw);
    const directionZ = -Math.cos(this.yaw);
    const nextX = this.position.x + directionX * this.speed * delta;
    const nextZ = this.position.z + directionZ * this.speed * delta;
    if (!city.collides(nextX, this.position.z, 1.36) && !city.collides(this.position.x, nextZ, 1.36)) {
      this.position.x = nextX;
      this.position.z = nextZ;
    } else {
      this.speed *= -0.12;
    }

    this.model.position.copy(this.position);
    this.model.rotation.y = this.yaw;
    const wheelSpin = this.speed * delta / 0.4;
    for (const wheel of this.wheels) {
      wheel.tire.rotation.x += wheelSpin;
      wheel.pivot.rotation.y = wheel.front ? -this.steering * 0.42 : 0;
    }
  }
}
