import { Game } from './core/Game.js';
import { UIManager } from './ui/UIManager.js';

const canvas = document.getElementById('game-canvas');

try {
  const game = new Game(canvas);
  const ui = new UIManager(game);
  ui.init();
  window.mirworkGame = game;
} catch (error) {
  console.error('YANGI OLAM ishga tushmadi:', error);
  const notice = document.getElementById('notice');
  notice.textContent = `O‘yin ishga tushmadi: ${error.message}`;
  notice.classList.add('visible', 'error');
}
