export class AudioManager {
  constructor() {
    this.context = null;
    this.master = null;
    this.engineOscillator = null;
    this.engineGain = null;
    this.volume = 0.55;
  }

  _ensureContext() {
    if (this.context) {
      if (this.context.state === 'suspended') this.context.resume().catch(() => {});
      return;
    }
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;
    this.context = new AudioContextClass();
    this.master = this.context.createGain();
    this.master.gain.value = this.volume;
    this.master.connect(this.context.destination);
  }

  setVolume(value) {
    this.volume = Math.min(1, Math.max(0, Number(value) || 0));
    if (this.master && this.context) this.master.gain.setTargetAtTime(this.volume, this.context.currentTime, 0.04);
  }

  click() {
    this._ensureContext();
    if (!this.context || !this.master) return;
    const oscillator = this.context.createOscillator();
    const gain = this.context.createGain();
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(620, this.context.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(380, this.context.currentTime + 0.075);
    gain.gain.setValueAtTime(0.0001, this.context.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.07, this.context.currentTime + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, this.context.currentTime + 0.09);
    oscillator.connect(gain);
    gain.connect(this.master);
    oscillator.start();
    oscillator.stop(this.context.currentTime + 0.1);
  }

  setEngine(active, speed = 0) {
    if (!active && !this.engineOscillator) return;
    this._ensureContext();
    if (!this.context || !this.master) return;
    if (active && !this.engineOscillator) {
      this.engineOscillator = this.context.createOscillator();
      this.engineGain = this.context.createGain();
      const filter = this.context.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 190;
      this.engineOscillator.type = 'sawtooth';
      this.engineOscillator.frequency.value = 48;
      this.engineGain.gain.value = 0.0001;
      this.engineOscillator.connect(filter);
      filter.connect(this.engineGain);
      this.engineGain.connect(this.master);
      this.engineOscillator.start();
    }
    if (this.engineOscillator && this.engineGain) {
      const target = active ? 0.018 + Math.min(Math.abs(speed) / 27, 1) * 0.035 : 0.0001;
      this.engineOscillator.frequency.setTargetAtTime(43 + Math.min(Math.abs(speed), 27) * 4.2, this.context.currentTime, 0.08);
      this.engineGain.gain.setTargetAtTime(target, this.context.currentTime, 0.12);
    }
  }
}
