const STORAGE_KEY = 'mirwork-yangi-olam-profile';
const LOCAL_SAVE_KEY = 'mirwork-yangi-olam-stage1-save';

export class SaveManager {
  constructor() {
    let profileId = localStorage.getItem(STORAGE_KEY);
    if (!profileId) {
      profileId = globalThis.crypto?.randomUUID?.() || 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, char => {
        const random = Math.random() * 16 | 0;
        return (char === 'x' ? random : (random & 0x3 | 0x8)).toString(16);
      });
      localStorage.setItem(STORAGE_KEY, profileId);
    }
    this.profileId = profileId;
    this.lastSave = null;
  }

  async load() {
    try {
      const response = await fetch(`/api/save/${this.profileId}`, { cache: 'no-store' });
      if (response.ok) {
        const result = await response.json();
        if (result.ok && result.data) {
          this.lastSave = result.data;
          localStorage.setItem(LOCAL_SAVE_KEY, JSON.stringify(result.data));
          return result.data;
        }
      }
    } catch (error) {
      console.warn('Serverdan saqlangan o‘yin olinmadi, mahalliy nusxa tekshiriladi:', error.message);
    }
    try {
      const raw = localStorage.getItem(LOCAL_SAVE_KEY);
      this.lastSave = raw ? JSON.parse(raw) : null;
      return this.lastSave;
    } catch {
      return null;
    }
  }

  async save(data) {
    const payload = {
      version: 1,
      cash: data.cash,
      player: data.player,
      vehicle: data.vehicle,
      settings: data.settings
    };
    localStorage.setItem(LOCAL_SAVE_KEY, JSON.stringify(payload));
    try {
      const response = await fetch(`/api/save/${this.profileId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!response.ok) throw new Error(`Server javobi: ${response.status}`);
      const result = await response.json();
      if (!result.ok) throw new Error(result.error || 'Saqlash bajarilmadi');
      this.lastSave = payload;
      return { ok: true, local: false };
    } catch (error) {
      console.warn('Serverga saqlash amalga oshmadi. Mahalliy nusxa saqlandi:', error.message);
      this.lastSave = payload;
      return { ok: true, local: true };
    }
  }
}
