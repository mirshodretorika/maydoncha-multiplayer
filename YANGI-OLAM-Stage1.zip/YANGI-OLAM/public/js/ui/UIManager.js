export class UIManager {
  constructor(game) {
    this.game = game;
    this.elements = Object.fromEntries([
      'intro', 'intro-progress', 'skip-intro', 'main-menu', 'hud', 'pause-menu',
      'settings-panel', 'about-panel', 'notice', 'cash-value', 'speed-value',
      'vehicle-hud', 'interaction-hint', 'save-indicator', 'help-toggle', 'help-card',
      'quality-value', 'volume-value', 'volume-slider'
    ].map(id => [id, document.getElementById(id)]));
    this.introStartedAt = 0;
    this.introFrame = 0;
    this.noticeTimer = 0;
    this.helpVisible = true;
    this._bindUI();
    this._bindGameEvents();
    this._applyMode(game.mode);
  }

  init() {
    this.game.start();
    this._startIntro();
  }

  _bindUI() {
    document.getElementById('start-new')?.addEventListener('click', () => {
      this.game.audio.click();
      this.game.startNewGame();
    });
    document.getElementById('continue-game')?.addEventListener('click', () => {
      this.game.audio.click();
      this.game.continueGame();
    });
    document.getElementById('open-settings')?.addEventListener('click', () => this.openPanel('settings'));
    document.getElementById('open-about')?.addEventListener('click', () => this.openPanel('about'));
    document.getElementById('resume-game')?.addEventListener('click', () => this.game.setMode('playing'));
    document.getElementById('save-game')?.addEventListener('click', () => this.game.saveGame(true));
    document.getElementById('pause-settings')?.addEventListener('click', () => this.openPanel('settings'));
    document.getElementById('return-menu')?.addEventListener('click', async () => {
      await this.game.saveGame(false);
      this.game.setMode('menu');
    });
    document.getElementById('close-settings')?.addEventListener('click', () => this.closePanels());
    document.getElementById('close-about')?.addEventListener('click', () => this.closePanels());
    document.getElementById('skip-intro')?.addEventListener('click', () => this._finishIntro());
    const toggleHelp = () => {
      this.helpVisible = !this.helpVisible;
      this.elements['help-card'].classList.toggle('hidden', !this.helpVisible);
      document.getElementById('help-toggle-mobile').classList.toggle('hidden', this.helpVisible);
    };
    this.elements['help-toggle']?.addEventListener('click', toggleHelp);
    document.getElementById('help-toggle-mobile')?.addEventListener('click', toggleHelp);

    document.querySelectorAll('[data-quality]').forEach(button => {
      button.addEventListener('click', () => {
        this.game.setQuality(button.dataset.quality);
        this._updateSettingsUI();
        this.game.audio.click();
      });
    });
    this.elements['volume-slider']?.addEventListener('input', event => {
      const value = Number(event.target.value) / 100;
      this.game.setVolume(value);
      this._updateSettingsUI();
    });

    window.addEventListener('keydown', event => {
      if (event.code !== 'Escape') return;
      if (!this.elements['settings-panel'].classList.contains('hidden') || !this.elements['about-panel'].classList.contains('hidden')) {
        this.closePanels();
        return;
      }
      if (this.game.mode === 'playing') {
        this.game.setMode('paused');
      } else if (this.game.mode === 'paused') {
        this.game.setMode('playing');
      }
    });
  }

  _bindGameEvents() {
    this.game.addEventListener('statechange', event => this._applyMode(event.detail));
    this.game.addEventListener('notice', event => this.showNotice(event.detail));
    this.game.addEventListener('telemetry', event => this._updateHUD(event.detail));
    this.game.addEventListener('settingschange', () => this._updateSettingsUI());
    this.game.addEventListener('savecomplete', event => {
      const status = event.detail.local ? 'MAHALLIY SAQLANDI' : 'SERVERGA SAQLANDI';
      this.elements['save-indicator'].textContent = status;
      this.elements['save-indicator'].classList.add('visible');
      window.clearTimeout(this.saveIndicatorTimer);
      this.saveIndicatorTimer = window.setTimeout(() => this.elements['save-indicator'].classList.remove('visible'), 2600);
    });
    this._updateSettingsUI();
  }

  _startIntro() {
    this.introStartedAt = performance.now();
    this.elements['intro'].classList.remove('hidden');
    const tick = now => {
      if (this.game.mode !== 'intro') return;
      const progress = Math.min(1, (now - this.introStartedAt) / 7000);
      this.elements['intro-progress'].style.transform = `scaleX(${progress})`;
      if (progress >= 1) {
        this._finishIntro();
        return;
      }
      this.introFrame = requestAnimationFrame(tick);
    };
    this.introFrame = requestAnimationFrame(tick);
  }

  _finishIntro() {
    cancelAnimationFrame(this.introFrame);
    this.elements['intro'].classList.add('fade-out');
    window.setTimeout(() => {
      this.elements['intro'].classList.add('hidden');
      this.elements['intro'].classList.remove('fade-out');
      this.game.setMode('menu');
    }, 420);
  }

  _applyMode(mode) {
    const isPlaying = mode === 'playing';
    this.elements['main-menu'].classList.toggle('hidden', mode !== 'menu');
    this.elements['hud'].classList.toggle('hidden', !isPlaying);
    this.elements['pause-menu'].classList.toggle('hidden', mode !== 'paused');
    if (mode !== 'playing') {
      this.elements['vehicle-hud'].classList.add('hidden');
      this.elements['interaction-hint'].classList.add('hidden');
    }
    if (mode === 'playing') {
      this.elements['help-card'].classList.toggle('hidden', !this.helpVisible);
      document.getElementById('help-toggle-mobile').classList.toggle('hidden', this.helpVisible);
    } else {
      document.getElementById('help-toggle-mobile').classList.add('hidden');
    }
  }

  _updateHUD(data) {
    if (this.game.mode !== 'playing') return;
    this.elements['cash-value'].textContent = `${Math.floor(data.cash).toLocaleString('uz-UZ')} so‘m`;
    this.elements['vehicle-hud'].classList.toggle('hidden', !data.driving);
    this.elements['speed-value'].textContent = `${data.speed} km/soat`;
    const distance = this.game.player.position.distanceTo(this.game.vehicle.position);
    const showEnter = !data.driving && distance <= 10;
    this.elements['interaction-hint'].classList.toggle('hidden', !showEnter);
    if (showEnter) this.elements['interaction-hint'].textContent = 'F  AVTOMOBILGA KIRISH';
  }

  _updateSettingsUI() {
    const quality = this.game.settings.quality;
    document.querySelectorAll('[data-quality]').forEach(button => {
      button.classList.toggle('active', button.dataset.quality === quality);
    });
    this.elements['quality-value'].textContent = quality === 'LOW' ? 'PAST' : quality === 'MEDIUM' ? 'O‘RTA' : 'YUQORI';
    this.elements['volume-slider'].value = Math.round(this.game.settings.volume * 100);
    this.elements['volume-value'].textContent = `${Math.round(this.game.settings.volume * 100)}%`;
  }

  openPanel(name) {
    this.elements['settings-panel'].classList.add('hidden');
    this.elements['about-panel'].classList.add('hidden');
    const panel = name === 'about' ? this.elements['about-panel'] : this.elements['settings-panel'];
    panel.classList.remove('hidden');
    this.game.audio.click();
  }

  closePanels() {
    this.elements['settings-panel'].classList.add('hidden');
    this.elements['about-panel'].classList.add('hidden');
    this.game.audio.click();
  }

  showNotice(message) {
    this.elements['notice'].textContent = message;
    this.elements['notice'].classList.add('visible');
    window.clearTimeout(this.noticeTimer);
    this.noticeTimer = window.setTimeout(() => this.elements['notice'].classList.remove('visible'), 2800);
  }
}
