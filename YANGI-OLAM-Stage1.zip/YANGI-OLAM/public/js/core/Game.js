import * as THREE from 'three';
import { City } from '../world/City.js';
import { PlayerController } from '../player/PlayerController.js';
import { VehicleController } from '../vehicles/VehicleController.js';
import { SaveManager } from '../systems/SaveManager.js';
import { AudioManager } from '../systems/AudioManager.js';

export class Game extends EventTarget {
  constructor(canvas) {
    super();
    this.canvas = canvas;
    this.mode = 'intro';
    this.cash = 2500;
    this.elapsed = 0;
    this.introElapsed = 0;
    this.lastTelemetry = 0;
    this.lastAutoSave = 0;
    this.vehicleCameraYaw = 0;
    this.vehicleCameraPitch = 0.2;
    this.settings = { quality: 'LOW', volume: 0.55 };
    this.saveManager = new SaveManager();
    this.audio = new AudioManager();
    this.clock = new THREE.Clock();
    this._raf = 0;
    this._boundAnimate = () => this._animate();

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x8b9ba7);
    this.scene.fog = new THREE.Fog(0x8b9ba7, 105, 420);
    this.camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.1, 1100);
    this.camera.position.set(-105, 60, 115);
    this.camera.lookAt(0, 10, 0);

    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: false,
      alpha: false,
      powerPreference: 'high-performance',
      stencil: false,
      depth: true
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = false;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1));
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);

    const hemi = new THREE.HemisphereLight(0xd8e8ff, 0x42483b, 1.55);
    this.scene.add(hemi);
    this.sun = new THREE.DirectionalLight(0xffe2bb, 2.0);
    this.sun.position.set(-90, 145, 85);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(1024, 1024);
    this.sun.shadow.camera.left = -190;
    this.sun.shadow.camera.right = 190;
    this.sun.shadow.camera.top = 190;
    this.sun.shadow.camera.bottom = -190;
    this.sun.shadow.camera.near = 1;
    this.sun.shadow.camera.far = 340;
    this.sun.shadow.bias = -0.00025;
    this.scene.add(this.sun);

    this.city = new City(this.scene);
    this.player = new PlayerController(this.scene);
    this.player.model.visible = false;
    this.vehicle = new VehicleController(this.scene);
    this._bindEvents();
    this.setQuality(this.settings.quality);
  }

  _bindEvents() {
    this._onKeyDown = event => {
      if (this.mode !== 'playing') return;
      if (event.code === 'KeyF') {
        event.preventDefault();
        if (!event.repeat) this.toggleVehicle();
        return;
      }
      if (event.code === 'KeyC' && !event.repeat && !this.vehicle.occupied) {
        this.player.crouching = !this.player.crouching;
        this._emitNotice(this.player.crouching ? 'Cho‘kkalash holati' : 'Tik turish holati');
        return;
      }
      if (this.vehicle.occupied) this.vehicle.handleKey(event.code, true);
      else this.player.handleKey(event.code, true);
    };
    this._onKeyUp = event => {
      this.player.handleKey(event.code, false);
      this.vehicle.handleKey(event.code, false);
    };
    this._onMouseMove = event => {
      if (document.pointerLockElement === this.canvas && this.mode === 'playing') {
        if (this.vehicle.occupied) {
          this.vehicleCameraYaw -= (event.movementX || 0) * 0.0022;
          this.vehicleCameraPitch = THREE.MathUtils.clamp(this.vehicleCameraPitch + (event.movementY || 0) * 0.0017, -0.12, 0.82);
        } else {
          this.player.rotateCamera(event.movementX || 0, event.movementY || 0);
        }
      }
    };
    this._onCanvasClick = () => {
      if (this.mode === 'playing' && document.pointerLockElement !== this.canvas) {
        this.canvas.requestPointerLock?.();
      }
    };
    this._onResize = () => this._resize();
    window.addEventListener('keydown', this._onKeyDown);
    window.addEventListener('keyup', this._onKeyUp);
    window.addEventListener('mousemove', this._onMouseMove);
    window.addEventListener('resize', this._onResize);
    this.canvas.addEventListener('click', this._onCanvasClick);
    this.canvas.addEventListener('contextmenu', event => event.preventDefault());
    document.addEventListener('pointerlockchange', () => {
      this.dispatchEvent(new Event('pointerlockchange'));
    });
  }

  _resize() {
    const width = Math.max(1, window.innerWidth);
    const height = Math.max(1, window.innerHeight);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height, false);
    this.renderer.setPixelRatio(this._pixelRatioForQuality());
  }

  _pixelRatioForQuality() {
    const cap = this.settings.quality === 'HIGH' ? 1.5 : this.settings.quality === 'MEDIUM' ? 1.25 : 1;
    return Math.min(window.devicePixelRatio || 1, cap);
  }

  setQuality(quality) {
    this.settings.quality = ['LOW', 'MEDIUM', 'HIGH'].includes(quality) ? quality : 'LOW';
    this.renderer.setPixelRatio(this._pixelRatioForQuality());
    this.renderer.shadowMap.enabled = this.settings.quality !== 'LOW';
    this.sun.shadow.mapSize.set(this.settings.quality === 'HIGH' ? 1536 : 1024, this.settings.quality === 'HIGH' ? 1536 : 1024);
    this.sun.shadow.needsUpdate = true;
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    this.dispatchEvent(new CustomEvent('settingschange', { detail: this.settings }));
  }

  setVolume(value) {
    this.settings.volume = THREE.MathUtils.clamp(Number(value) || 0, 0, 1);
    this.audio.setVolume(this.settings.volume);
    this.dispatchEvent(new CustomEvent('settingschange', { detail: this.settings }));
  }

  setMode(mode) {
    this.mode = mode;
    if (mode !== 'playing') {
      this.player.keys.clear();
      this.vehicle.keys.clear();
    }
    if (mode === 'menu' || mode === 'intro') this.player.model.visible = false;
    if (mode !== 'playing' && document.pointerLockElement === this.canvas) document.exitPointerLock?.();
    this.dispatchEvent(new CustomEvent('statechange', { detail: mode }));
  }

  start() {
    if (!this._raf) this._animate();
  }

  _animate() {
    this._raf = requestAnimationFrame(this._boundAnimate);
    const delta = Math.min(this.clock.getDelta(), 0.05);
    this.currentDelta = delta;
    this.elapsed += delta;
    this.city.update(delta);

    if (this.mode === 'intro') {
      this.introElapsed += delta;
      this._updateIntroCamera();
    } else if (this.mode === 'menu') {
      this._updateMenuCamera();
    } else if (this.mode === 'playing') {
      if (this.vehicle.occupied) this.vehicle.update(delta, this.city);
      else this.player.update(delta, this.city, this.vehicle);
      this._updateFollowCamera(delta);
      this.audio.setEngine(this.vehicle.occupied, this.vehicle.speed);
      this.lastAutoSave += delta;
      if (this.lastAutoSave >= 22) {
        this.lastAutoSave = 0;
        this.saveGame(false);
      }
      if (this.elapsed - this.lastTelemetry >= 0.12) {
        this.lastTelemetry = this.elapsed;
        this.dispatchEvent(new CustomEvent('telemetry', { detail: this.getTelemetry() }));
      }
    } else {
      this.audio.setEngine(false, 0);
    }

    this.renderer.render(this.scene, this.camera);
  }

  _updateIntroCamera() {
    const t = Math.min(this.introElapsed / 7, 1);
    const ease = t * t * (3 - 2 * t);
    const start = new THREE.Vector3(-108, 66, 122);
    const middle = new THREE.Vector3(80, 43, -56);
    const end = new THREE.Vector3(0, 26, 78);
    let position;
    if (t < 0.57) position = start.clone().lerp(middle, ease / 0.57);
    else position = middle.clone().lerp(end, (ease - 0.57) / 0.43);
    this.camera.position.copy(position);
    const target = new THREE.Vector3(Math.sin(t * 5) * 10, 8 + (1 - t) * 5, 0);
    this.camera.lookAt(target);
  }

  _updateMenuCamera() {
    const t = this.elapsed;
    this.camera.position.set(Math.sin(t * 0.075) * 13, 21 + Math.sin(t * 0.11) * 1.1, 82 + Math.cos(t * 0.075) * 4);
    this.camera.lookAt(0, 8, 0);
  }

  _updateFollowCamera(delta) {
    const driving = this.vehicle.occupied;
    const target = driving ? this.vehicle.cameraTarget : new THREE.Vector3(this.player.position.x, this.player.position.y + 1.25, this.player.position.z);
    const yaw = driving ? this.vehicleCameraYaw : this.player.cameraYaw;
    const pitch = driving ? this.vehicleCameraPitch : this.player.cameraPitch;
    const distance = driving ? 10.5 : 6.8;
    const horizontal = Math.cos(pitch) * distance;
    const desired = new THREE.Vector3(
      target.x + Math.sin(yaw) * horizontal,
      target.y + 1.15 + Math.sin(pitch) * distance,
      target.z + Math.cos(yaw) * horizontal
    );
    this.camera.position.lerp(desired, 1 - Math.exp(-7.5 * delta));
    this.camera.lookAt(target.x, target.y + (driving ? 0.15 : 0.2), target.z);
  }

  toggleVehicle() {
    if (this.mode !== 'playing') return;
    if (this.vehicle.occupied) {
      const exitPoint = this.vehicle.exitPosition(this.city);
      if (!exitPoint) {
        this._emitNotice('Bu tomondan tushish uchun joy yo‘q.');
        return;
      }
      this.player.position.copy(exitPoint);
      this.player.velocity.set(0, 0, 0);
      this.player.model.position.copy(exitPoint);
      this.player.model.visible = true;
      this.player.yaw = this.vehicle.yaw + Math.PI;
      this.player.cameraYaw = this.vehicleCameraYaw;
      this.vehicle.leave();
      this._emitNotice('Avtomobildan tushdingiz.');
    } else if (this.vehicle.canEnter(this.player.position)) {
      this.vehicle.enter();
      this.vehicleCameraYaw = this.vehicle.yaw;
      this.vehicleCameraPitch = 0.2;
      this.player.keys.clear();
      this.player.model.visible = false;
      this.player.cameraYaw = this.vehicle.yaw;
      this._emitNotice('Avtomobil boshqaruvi: WASD. Tushish: F.');
    } else {
      this._emitNotice('Avtomobilga yaqinroq boring.');
    }
  }

  async startNewGame() {
    this.cash = 2500;
    this.player.reset(new THREE.Vector3(4, 0, 9), Math.PI);
    this.vehicle.reset(new THREE.Vector3(8, 0, 0), 0);
    this.vehicleCameraYaw = 0;
    this.vehicleCameraPitch = 0.2;
    this.player.model.visible = true;
    this.setMode('playing');
    this.audio.click();
    await this.saveGame(false);
    this._emitNotice('Xush kelibsiz! WASD bilan harakatlaning.');
  }

  async continueGame() {
    const saved = await this.saveManager.load();
    if (saved) {
      this.cash = Number.isFinite(saved.cash) ? saved.cash : 2500;
      this.player.reset(
        new THREE.Vector3(saved.player?.x ?? 4, 0, saved.player?.z ?? 9),
        saved.player?.yaw ?? Math.PI
      );
      this.vehicle.reset(
        new THREE.Vector3(saved.vehicle?.x ?? 8, 0, saved.vehicle?.z ?? 0),
        saved.vehicle?.yaw ?? 0
      );
      this.vehicleCameraYaw = this.vehicle.yaw;
      if (saved.settings) {
        this.setQuality(saved.settings.quality || 'LOW');
        this.setVolume(saved.settings.volume ?? 0.55);
      }
    } else {
      this.cash = 2500;
      this.player.reset();
      this.vehicle.reset();
    }
    this.player.model.visible = true;
    this.setMode('playing');
    this.audio.click();
    this._emitNotice(saved ? 'Saqlangan o‘yin yuklandi.' : 'Hali saqlangan o‘yin yo‘q. Yangi sayohat boshlandi.');
  }

  async saveGame(showNotice = true) {
    const payload = {
      cash: this.cash,
      player: {
        x: this.player.position.x,
        z: this.player.position.z,
        yaw: this.player.yaw
      },
      vehicle: {
        x: this.vehicle.position.x,
        z: this.vehicle.position.z,
        yaw: this.vehicle.yaw,
        owned: true
      },
      settings: { ...this.settings }
    };
    const result = await this.saveManager.save(payload);
    this.dispatchEvent(new CustomEvent('savecomplete', { detail: result }));
    if (showNotice) this._emitNotice(result.local ? 'Mahalliy nusxa saqlandi; serverga ulanish yo‘q.' : 'O‘yin serverga saqlandi.');
    return result;
  }

  getTelemetry() {
    return {
      cash: this.cash,
      speed: Math.round(Math.abs(this.vehicle.speed) * 3.6),
      driving: this.vehicle.occupied,
      position: this.vehicle.occupied ? this.vehicle.position : this.player.position,
      location: 'Yangi shahar',
      fps: Math.round(1 / Math.max(this.currentDelta || 0.016, 0.001))
    };
  }

  _emitNotice(message) {
    this.dispatchEvent(new CustomEvent('notice', { detail: message }));
  }

  dispose() {
    cancelAnimationFrame(this._raf);
    window.removeEventListener('keydown', this._onKeyDown);
    window.removeEventListener('keyup', this._onKeyUp);
    window.removeEventListener('mousemove', this._onMouseMove);
    window.removeEventListener('resize', this._onResize);
    this.canvas.removeEventListener('click', this._onCanvasClick);
    this.renderer.dispose();
  }
}
