import * as THREE from 'three';

export class PlayerController {
  constructor(scene) {
    this.scene = scene;
    this.position = new THREE.Vector3(4, 0, 9);
    this.velocity = new THREE.Vector3();
    this.yaw = Math.PI;
    this.cameraYaw = 0;
    this.cameraPitch = 0.28;
    this.verticalSpeed = 0;
    this.onGround = true;
    this.crouching = false;
    this.keys = new Set();
    this.jumpRequested = false;
    this.walkPhase = 0;
    this.speed = 0;
    this.model = this._createCharacter();
    this.model.position.copy(this.position);
    this.scene.add(this.model);
  }

  _createCharacter() {
    const root = new THREE.Group();
    const skin = new THREE.MeshStandardMaterial({ color: 0xc58d68, roughness: 0.78 });
    const jacket = new THREE.MeshStandardMaterial({ color: 0x243b55, roughness: 0.78 });
    const pants = new THREE.MeshStandardMaterial({ color: 0x202832, roughness: 0.88 });
    const shoes = new THREE.MeshStandardMaterial({ color: 0x141a20, roughness: 0.85 });
    const hair = new THREE.MeshStandardMaterial({ color: 0x25201d, roughness: 0.95 });

    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.34, 0.48, 4, 8), jacket);
    torso.position.y = 1.28;
    torso.castShadow = true;
    root.add(torso);

    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.105, 0.12, 0.18, 8), skin);
    neck.position.y = 1.77;
    root.add(neck);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.235, 12, 10), skin);
    head.position.set(0, 1.98, 0.015);
    head.castShadow = true;
    root.add(head);

    const hairCap = new THREE.Mesh(new THREE.SphereGeometry(0.239, 12, 7, 0, Math.PI * 2, 0, Math.PI * 0.55), hair);
    hairCap.position.set(0, 2.035, 0.012);
    root.add(hairCap);

    this.leftArm = new THREE.Group();
    this.rightArm = new THREE.Group();
    for (const [pivot, side] of [[this.leftArm, -1], [this.rightArm, 1]]) {
      pivot.position.set(side * 0.43, 1.53, 0);
      const upper = new THREE.Mesh(new THREE.CapsuleGeometry(0.105, 0.44, 3, 7), jacket);
      upper.position.y = -0.29;
      upper.castShadow = true;
      pivot.add(upper);
      const hand = new THREE.Mesh(new THREE.SphereGeometry(0.095, 8, 7), skin);
      hand.position.y = -0.58;
      pivot.add(hand);
      root.add(pivot);
    }

    this.leftLeg = new THREE.Group();
    this.rightLeg = new THREE.Group();
    for (const [pivot, side] of [[this.leftLeg, -1], [this.rightLeg, 1]]) {
      pivot.position.set(side * 0.17, 0.88, 0);
      const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.14, 0.52, 3, 7), pants);
      leg.position.y = -0.36;
      leg.castShadow = true;
      pivot.add(leg);
      const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.12, 0.38), shoes);
      shoe.position.set(0, -0.68, 0.075);
      shoe.castShadow = true;
      pivot.add(shoe);
      root.add(pivot);
    }

    const shadow = new THREE.Mesh(
      new THREE.CircleGeometry(0.48, 16),
      new THREE.MeshBasicMaterial({ color: 0x111820, transparent: true, opacity: 0.28, depthWrite: false })
    );
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = 0.015;
    root.add(shadow);
    return root;
  }

  handleKey(code, isDown) {
    if (isDown) {
      if (!this.keys.has(code) && code === 'Space') this.jumpRequested = true;
      this.keys.add(code);
    } else {
      this.keys.delete(code);
    }
  }

  rotateCamera(deltaX, deltaY) {
    this.cameraYaw -= deltaX * 0.0022;
    this.cameraPitch = THREE.MathUtils.clamp(this.cameraPitch + deltaY * 0.0017, -0.12, 0.82);
  }

  reset(position = new THREE.Vector3(4, 0, 9), yaw = Math.PI) {
    this.position.copy(position);
    this.velocity.set(0, 0, 0);
    this.keys.clear();
    this.crouching = false;
    this.verticalSpeed = 0;
    this.yaw = yaw;
    this.cameraYaw = yaw + Math.PI;
    this.cameraPitch = 0.28;
    this.model.position.copy(this.position);
    this.model.rotation.y = this.yaw;
  }

  update(delta, city, vehicle = null) {
    const forwardInput = (this.keys.has('KeyW') ? 1 : 0) - (this.keys.has('KeyS') ? 1 : 0);
    const rightInput = (this.keys.has('KeyD') ? 1 : 0) - (this.keys.has('KeyA') ? 1 : 0);
    const inputLength = Math.hypot(forwardInput, rightInput);
    const inputScale = inputLength > 1 ? 1 / inputLength : 1;
    const forward = new THREE.Vector3(-Math.sin(this.cameraYaw), 0, -Math.cos(this.cameraYaw));
    const right = new THREE.Vector3(Math.cos(this.cameraYaw), 0, -Math.sin(this.cameraYaw));
    const desired = forward.multiplyScalar(forwardInput * inputScale)
      .add(right.multiplyScalar(rightInput * inputScale));

    const sprinting = this.keys.has('ShiftLeft') || this.keys.has('ShiftRight');
    const maxSpeed = this.crouching ? 1.8 : (sprinting ? 7.2 : 4.4);
    const targetX = desired.x * maxSpeed;
    const targetZ = desired.z * maxSpeed;
    const smoothing = desired.lengthSq() > 0 ? 1 - Math.exp(-13 * delta) : 1 - Math.exp(-9 * delta);
    this.velocity.x = THREE.MathUtils.lerp(this.velocity.x, targetX, smoothing);
    this.velocity.z = THREE.MathUtils.lerp(this.velocity.z, targetZ, smoothing);

    if (this.jumpRequested && this.onGround && !this.crouching) {
      this.verticalSpeed = 6.2;
      this.onGround = false;
    }
    this.jumpRequested = false;
    this.verticalSpeed -= 17 * delta;
    this.position.y += this.verticalSpeed * delta;
    if (this.position.y <= 0) {
      this.position.y = 0;
      this.verticalSpeed = 0;
      this.onGround = true;
    }

    const radius = 0.48;
    const blocked = (x, z) => {
      if (city.collides(x, z, radius)) return true;
      if (vehicle && !vehicle.occupied && Math.hypot(x - vehicle.position.x, z - vehicle.position.z) < 2.1) return true;
      return false;
    };
    const nextX = this.position.x + this.velocity.x * delta;
    if (!blocked(nextX, this.position.z)) this.position.x = nextX;
    else this.velocity.x = 0;
    const nextZ = this.position.z + this.velocity.z * delta;
    if (!blocked(this.position.x, nextZ)) this.position.z = nextZ;
    else this.velocity.z = 0;

    this.speed = Math.hypot(this.velocity.x, this.velocity.z);
    if (this.speed > 0.12) {
      this.yaw = Math.atan2(this.velocity.x, this.velocity.z);
    }
    this.model.position.copy(this.position);
    this.model.rotation.y = this.yaw;

    const walking = this.speed > 0.35 && this.onGround;
    if (walking) this.walkPhase += delta * (sprinting ? 12 : 8) * (this.crouching ? 0.65 : 1);
    const swing = walking ? Math.sin(this.walkPhase) * 0.55 : 0;
    this.leftLeg.rotation.x = swing;
    this.rightLeg.rotation.x = -swing;
    this.leftArm.rotation.x = -swing * 0.8;
    this.rightArm.rotation.x = swing * 0.8;
    this.model.scale.y = this.crouching ? 0.84 : 1;
  }
}
