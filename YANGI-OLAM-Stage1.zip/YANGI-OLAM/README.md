# YANGI OLAM — DO‘STLAR BILAN

**MIRWORK STUDIOS · 1-bosqich: Game Foundation · v0.1.0**

Brauzerda ishlaydigan, Three.js asosidagi uch o‘lchamli ochiq dunyo o‘yinining birinchi ishlaydigan bosqichi. Shahar binolari, daraxtlar, yo‘llar, chiroqlar, qahramon va avtomobil tashqi 3D model fayllarisiz protsedurali geometriya orqali yaratiladi.

## Ishga tushirish

Talablar: Node.js 18 yoki undan yangi versiya, npm va WebGL 2 ni qo‘llaydigan zamonaviy brauzer.

1. Loyihaning `YANGI-OLAM` papkasini oching.
2. Terminalda quyidagilarni bajaring:

```bash
npm install
npm start
```

3. Brauzerda `http://localhost:3000` manzilini oching.
4. Birinchi kirishda 7 soniyalik cinematic intro ko‘rsatiladi. Uni `O‘TKAZIB YUBORISH` tugmasi bilan o‘tkazib yuborish mumkin.

`npm run dev` buyrug‘i Node.js kuzatuv rejimini ishga tushiradi.

## Boshqaruv

| Tugma | Vazifasi |
|---|---|
| `W A S D` | Yurish / avtomobilni boshqarish |
| `SHIFT` | Yugurish |
| `SPACE` | Sakrash / avtomobilda qo‘l tormozi |
| `C` | Cho‘kkalash holatini yoqish/o‘chirish |
| `F` | Yaqindagi avtomobilga kirish / undan tushish |
| Sichqoncha | Uchinchi shaxs kamerasi |
| `ESC` | Pauza menyusi |

Kamera boshqaruvi uchun o‘yin maydonini bir marta bosing. Brauzer sichqoncha boshqaruviga ruxsat so‘rashi mumkin.

## 1-bosqichda ishlaydigan qismlar

- 7 soniyalik cinematic intro va skip tugmasi.
- 3D shahar: yo‘l tarmog‘i, binolar, parklar, daraxtlar, yo‘l chiziqlari va ko‘cha chiroqlari.
- Uchinchi shaxs kamerasi, qahramon modeli, yurish/yugurish/sakrash/cho‘kkalash.
- Shahar binolari va xarita chegaralari bilan asosiy to‘qnashuv tekshiruvi.
- Protsedurali avtomobil modeli, tezlanish, tormoz, burilish, g‘ildirak aylanishi va to‘siqqa urilish.
- `F` tugmasi bilan avtomobilga kirish va undan xavfsiz joyda tushish.
- HUD, avtomobil tezligi, naqd pul ko‘rsatkichi va boshqaruv yordami.
- ESC pauza menyusi, grafik sifati va ovoz sozlamalari.
- Serverga saqlash (`database/saves.json`) va server ishlamasa brauzerning mahalliy nusxasiga zaxira saqlash.

## Saqlash haqida

Har bir brauzer profiliga alohida tasodifiy profil identifikatori beriladi. O‘yin holati serverning `database/saves.json` fayliga yoziladi. Serverga ulanish muvaffaqiyatsiz bo‘lsa, o‘yin brauzerning `localStorage` xotirasidagi zaxira nusxani yangilaydi. Hozircha bu mehmon profili; ro‘yxatdan o‘tish, autentifikatsiya va bir nechta qurilmada hisobni tiklash yo‘q.

## Hozircha 1-bosqichga kirmaydigan tizimlar

Bu versiya hali to‘liq GTA-uslubidagi o‘yin yoki multiplayer relizi emas. Quyidagilar keyingi bosqichlarda ishlab chiqilishi kerak: 30 o‘yinchili Socket.IO multiplayer, akkauntlar va DB autentifikatsiyasi, to‘liq personaj yaratish, uy/biznes/iqtisodiyot, ishlar, inventar va do‘konlar, hikoya va 15 missiya, politsiya va qamoqxona, NPC kundalik hayoti, kengaytirilgan suv/ob-havo/fasllar, qurol va jang tizimlari, to‘liq animatsiya/audio kontenti.

Ushbu ro‘yxat ataylab ochiq ko‘rsatilgan: mavjud bo‘lmagan funksiyalar tayyor deb belgilanmaydi.

## Texnik tuzilma

```text
YANGI-OLAM/
├── package.json
├── server.js
├── database/
│   └── saves.json
├── public/
│   ├── index.html
│   ├── css/
│   │   └── styles.css
│   ├── assets/
│   │   ├── models/
│   │   ├── textures/
│   │   ├── audio/
│   │   └── fonts/
│   └── js/
│       ├── main.js
│       ├── core/Game.js
│       ├── world/City.js
│       ├── player/PlayerController.js
│       ├── vehicles/VehicleController.js
│       ├── ui/UIManager.js
│       └── systems/
│           ├── SaveManager.js
│           └── AudioManager.js
└── README.md
```

## Eslatma

Three.js `0.170.0` va Express `4.21.2` npm orqali o‘rnatiladi. Birinchi ishga tushirish uchun `npm install` talab qilinadi. O‘yin LOW grafik rejimida boshlanadi; MEDIUM va HIGH rejimlari sozlamalardan tanlanadi.
