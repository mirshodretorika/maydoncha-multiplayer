import express from 'express';
import path from 'node:path';
import fs from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(ROOT, 'database');
const SAVE_FILE = path.join(DATA_DIR, 'saves.json');
const app = express();

app.disable('x-powered-by');
app.use(express.json({ limit: '32kb' }));
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

await fs.mkdir(DATA_DIR, { recursive: true });
try {
  await fs.access(SAVE_FILE);
} catch {
  await fs.writeFile(SAVE_FILE, '{}\n', 'utf8');
}

let saveQueue = Promise.resolve();
async function readSaves() {
  try {
    const raw = await fs.readFile(SAVE_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch (error) {
    console.error('[Saqlash] Faylni o‘qib bo‘lmadi:', error.message);
    return {};
  }
}
async function writeSaves(data) {
  const tempFile = `${SAVE_FILE}.tmp`;
  await fs.writeFile(tempFile, `${JSON.stringify(data, null, 2)}\n`, 'utf8');
  await fs.rename(tempFile, SAVE_FILE);
}
function validProfileId(id) {
  return typeof id === 'string' && /^[a-f0-9-]{20,50}$/i.test(id);
}
function clampNumber(value, min, max, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.min(max, Math.max(min, number)) : fallback;
}
function sanitizeSave(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return null;
  const player = input.player && typeof input.player === 'object' ? input.player : {};
  const vehicle = input.vehicle && typeof input.vehicle === 'object' ? input.vehicle : {};
  return {
    version: 1,
    updatedAt: Date.now(),
    cash: Math.floor(clampNumber(input.cash, 0, 1_000_000_000, 2500)),
    player: {
      x: clampNumber(player.x, -270, 270),
      z: clampNumber(player.z, -270, 270),
      yaw: clampNumber(player.yaw, -Math.PI * 100, Math.PI * 100)
    },
    vehicle: {
      x: clampNumber(vehicle.x, -270, 270, 5),
      z: clampNumber(vehicle.z, -270, 270, 5),
      yaw: clampNumber(vehicle.yaw, -Math.PI * 100, Math.PI * 100),
      owned: Boolean(vehicle.owned)
    },
    settings: {
      quality: ['LOW', 'MEDIUM', 'HIGH'].includes(input.settings?.quality) ? input.settings.quality : 'LOW',
      volume: clampNumber(input.settings?.volume, 0, 1, 0.55)
    }
  };
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, game: 'YANGI OLAM — DO‘STLAR BILAN', stage: 1 });
});

app.get('/api/save/:id', async (req, res) => {
  if (!validProfileId(req.params.id)) return res.status(400).json({ ok: false, error: 'Profil identifikatori noto‘g‘ri.' });
  const saves = await readSaves();
  res.json({ ok: true, data: saves[req.params.id] || null });
});

app.post('/api/save/:id', async (req, res) => {
  if (!validProfileId(req.params.id)) return res.status(400).json({ ok: false, error: 'Profil identifikatori noto‘g‘ri.' });
  const clean = sanitizeSave(req.body);
  if (!clean) return res.status(400).json({ ok: false, error: 'Saqlash ma’lumoti noto‘g‘ri.' });
  saveQueue = saveQueue.catch(() => {}).then(async () => {
    const saves = await readSaves();
    saves[req.params.id] = clean;
    await writeSaves(saves);
  });
  try {
    await saveQueue;
    res.json({ ok: true, savedAt: clean.updatedAt });
  } catch (error) {
    console.error('[Saqlash] Yozish xatosi:', error);
    res.status(500).json({ ok: false, error: 'Saqlash vaqtida server xatosi yuz berdi.' });
  }
});

app.use('/vendor/three', express.static(path.join(ROOT, 'node_modules/three'), {
  maxAge: '7d',
  immutable: true
}));
app.use(express.static(path.join(ROOT, 'public')));
app.get('*', (_req, res) => res.sendFile(path.join(ROOT, 'public/index.html')));

app.listen(PORT, () => {
  console.log(`\nYANGI OLAM — DO‘STLAR BILAN`);
  console.log(`MIRWORK STUDIOS | 1-bosqich: Game Foundation`);
  console.log(`O‘yin manzili: http://localhost:${PORT}\n`);
});
